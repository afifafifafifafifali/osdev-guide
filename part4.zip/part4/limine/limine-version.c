#include <stdio.h>

#define LIMINE_VERSION "4.20231024.eol"

int main(void) {
    puts(LIMINE_VERSION);
}
