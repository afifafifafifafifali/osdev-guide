#include <stdint.h>

void itoa(int value, char* str, int base);
void uint64toa(uint64_t value, char* str, int base);
