#include <stdint.h>

void printNumber(uint64_t num);
