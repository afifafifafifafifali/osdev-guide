#include "heap.h"

#define HEAP_START 4096
#define HEAP_END 4096


void* malloc(size_t size) 
{
    return NULL;     
}


